package pachiSlot;

public enum ReelState {
	Stop,
	Rolling,
	Slipping
}
