package pachiSlot;

public class Yaku {
	public int num;
	public Role role;
	public Yaku(Role role,int num) {
		this.num = num;
		this.role = role;
	}
}
