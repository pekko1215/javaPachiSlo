package pachiSlot;

public enum GameMode {
	Normal,
	Bonus,
	Regular,
	Jac
}