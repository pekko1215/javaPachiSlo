package pachiSlot.effect;

public enum ARTMode {
	Low,
	High,
	VeryHigh
}
