package pachiSlot;

public enum GameState {
	BetWait,
	Beted,
	Wait,
	Rolling,
	Pay
}
