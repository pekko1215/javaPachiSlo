package pachiSlot;

public enum ControlCode {
	はずれ,
	リプレイ,
	共通8枚役,
	スイカ,
	チェリー,
	リーチ目リプレイ,
	BIG,
	チャンスプラム,
	ボーナス制御,
	突入左,
	突入中,
	突入右,
	赤8枚,
	青8枚,
	BAR8枚,
}
